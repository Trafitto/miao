Miao
------

Print a cat, a simple exercise to train me to create python packages

To use (with caution), simply do::
import miao
miao.Meow()