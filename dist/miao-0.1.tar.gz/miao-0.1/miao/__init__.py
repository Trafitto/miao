def Meow():
	print(' /\_/\ \n'+'( °Y° )')