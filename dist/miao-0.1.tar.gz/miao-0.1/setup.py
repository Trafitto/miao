from setuptools import setup

setup(name='miao',
      version='0.1',
      description='Print a cat',
      url='https://github.com/Trafitto/miao',
      author='trafitto',
      author_email='develop@trafitto.com',
      license='MIT',
      packages=['miao'],
      zip_safe=False)