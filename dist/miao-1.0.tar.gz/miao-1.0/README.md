Miao
=============================

Print a cat, a simple exercise to train me to create python packages

To use::

	pip install miao

	import miao
	miao.Meow()

	or:

	from miao import Meow
	Meow()

	You can pass the name of the cat Meow("Bob")

----

The cat::

	 /\_/\
	( °Y° )
	
----