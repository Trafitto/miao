from setuptools import setup
		
setup(name='miao',
      version='1.0',
      description='Print a cat',
	  long_description="Print a cat, a simple exercise to train me to create python packages",
      url='https://github.com/Trafitto/miao',
      author='trafitto',
      author_email='develop@trafitto.com',
      license='MIT',
      packages=['miao'],
      zip_safe=False)